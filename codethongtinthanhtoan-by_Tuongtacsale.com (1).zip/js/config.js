const USER = {
    banks: [{
            name: "MB BANK",
            logo: "./images/mbbank.png",
            number: "7895858888888",
            owner: "TRAN MINH DUC"
        },
        {
            name: "VIETCOMBANK",
            logo: "./images/vietcombank.png",
            number: "1028510335",
            owner: "TRAN MINH DUC"
        },
        {
            name: "THESIEURE",
            logo: "./images/thesieure.png",
            number: "0363815826",
            owner: "TRAN MINH DUC"
        },
        {
            name: "PAYPAL",
            logo: "./images/paypal.png",
            number: "STTCHAT123@GMAIL.COM",
            owner: "TRAN MINH DUC"
        },
        {
            name: "MOMO",
            logo: "./images/momo.jpeg",
            number: "0363815826",
            owner: "TRAN MINH DUC",
        
        },
        {
            name: "ZALO PAY",
            logo: "./images/zalopay.png",
            number: "0363815826",
            owner: "TRAN MINH DUC"
        },
        {
            name: "VIETTEL PAY",
            logo: "./images/viettelpay.png",
            number: "0363815826",
            owner: "TRAN MINH DUC"
        },
        {
            name: "BINANCE",
            logo: "./images/binance.png",
            number: "sttchat123@gmail.com",
            owner: "DucPolime"
        },
    ]
};